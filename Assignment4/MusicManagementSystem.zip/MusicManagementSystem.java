import java.util.*;

class Song {

    int songId;
    String songTitle;
    String artistName;
    String albumTitle;
    String genre;
    int durationInSeconds;
    int playCount;

    Song() {
        songId = 0;
        songTitle = "";
        artistName = "";
        albumTitle = "";
        genre = "";
        durationInSeconds = 0;
        playCount = 0;
    }

    public void setDetails(int id, String title, String name, String album, String genre, int duration) {
        songId = id;
        songTitle = title;
        artistName = name;
        albumTitle = album;
        this.genre = genre;
        durationInSeconds = duration;
    }

    public void getDetails(int id) {
        System.out.println("Id = " + id);
        System.out.println("Song title = " + songTitle);
        System.out.println("Artist name = " + artistName);
        System.out.println("Album name = " + albumTitle);
        System.out.println("Genre = " + genre);
        System.out.println("Duration in seconds = " + durationInSeconds);
    }

    public void play(int id) {
        System.out.println("Song played: " + songTitle);
    }

    ArrayList<String> playlist = new ArrayList<String>();

    public void addToPlaylist(int id) {
        playlist.add(songTitle);
    }

    public void removeFromPlaylist(int id) {
        playlist.remove(songTitle);
    }

}

public class MusicManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of objects: ");
        int n = sc.nextInt();

        Song[] obj = new Song[n];
        ArrayList<Song> songList = new ArrayList<Song>();
        int id;
        String title, name, album, genre;
        int duration;

        for (int i = 0; i < n; i++) {
            obj[i] = new Song();
            System.out.println("\nFor object " + (i + 1) + ": ");
            System.out.print("Enter the id: ");
            id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter the song title: ");
            title = sc.nextLine();
            System.out.print("Enter the artist name: ");
            name = sc.nextLine();
            System.out.print("Enter the album name: ");
            album = sc.nextLine();
            System.out.print("Enter the genre: ");
            genre = sc.nextLine();
            System.out.print("Enter the duration: ");
            duration = sc.nextInt();
            obj[i].setDetails(id, title, name, album, genre, duration);
            songList.add(obj[i]);

        }

        char ans = 'Y';
        int ch;
        while (ans == 'Y' || ans == 'y') {
            System.out.println("\n");
            System.out.println("1.Set details");
            System.out.println("2.Get details");
            System.out.println("3.Play");
            System.out.println("4.Add to playlist");
            System.out.println("5.Remove from playlist");
            System.out.println("6.Exit");
            System.out.print("Enter your choice: ");
            ch = sc.nextInt();

            switch (ch) {
                case 1:
                    Song object = new Song();

                    System.out.print("Enter the id: ");
                    id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter the song title: ");
                    title = sc.nextLine();
                    System.out.print("Enter the artist name: ");
                    name = sc.nextLine();
                    System.out.print("Enter the album name: ");
                    album = sc.nextLine();
                    System.out.print("Enter the genre: ");
                    genre = sc.nextLine();
                    System.out.print("Enter the duration: ");
                    duration = sc.nextInt();

                    object.setDetails(id, title, name, album, genre, duration);
                    songList.add(object);
                    break;

                case 2:
                    System.out.println("\nEnter the required id: ");
                    int id1 = sc.nextInt();
                    for (int i = 0; i < n; i++) {
                        if (obj[i].songId == id1) {
                            obj[i].getDetails(id1);
                        }
                    }
                    break;

                case 3:
                    System.out.println("Enter the required id: ");
                    int id2 = sc.nextInt();
                    for (int i = 0; i < n; i++) {
                        if (obj[i].songId == id2) {
                            obj[i].play(id2);
                        }
                    }
                    break;

                case 4:
                    System.out.println("Enter the required id: ");
                    int id3 = sc.nextInt();
                    for (int i = 0; i < n; i++) {
                        if (obj[i].songId == id3) {
                            obj[i].addToPlaylist(id3);
                        }
                    }
                    break;

                case 5:
                    System.out.println("Enter the required id: ");
                    int id4 = sc.nextInt();
                    for (int i = 0; i < n; i++) {
                        if (obj[i].songId == id4) {
                            obj[i].removeFromPlaylist(id4);
                        }
                    }
                    break;

                case 6:
                    System.out.println("Exit from system");
                    break;

                default:
                    System.out.println("Invalid choice,try again");
            }
            System.out.print("Do you want to continue(y/n)? ");
            ans = sc.next().charAt(0);
        }

        sc.close();
    }
}
